from enum import Enum

class ReductionType(Enum):
    SVD = 1
    PCA = 2
    LDA = 3
    NMF = 4