class Model:
    def getFeatures(self):
        pass
    def compare(self, modelInstance):
        pass