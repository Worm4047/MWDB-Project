from enum import Enum

class ModelType(Enum):
    CM = 1
    LBP = 2
    HOG = 3
    SIFT = 4
